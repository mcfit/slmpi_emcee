grep "^#define MODULE_VERSION_NUMSTR" version.h | tr -dc '0123456789.'
