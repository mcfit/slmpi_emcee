#include "misc.hh"

int main()
{
   string arr[] = {"green", "cyan", "aqua", "violet", "gray"};
   stringlist_print(5, arr);

   StructClassAlias sca(6.6);
   ClassClassAlias cca();

   return 0;
}
