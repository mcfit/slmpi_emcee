#ifndef __CDECL_HH__
#define __CDECL_HH__

#define BEGIN_C_DECL		extern "C" {
#define END_C_DECL		}
  
#endif
