void c_cadd(spcomplex a, spcomplex b, spcomplex *c);
