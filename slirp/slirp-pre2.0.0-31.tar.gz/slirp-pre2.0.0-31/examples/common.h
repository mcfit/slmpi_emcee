#if SLANG_VERSION < 20000
#define SLang_set_error(x)      (SLang_Error = (x))
#endif
