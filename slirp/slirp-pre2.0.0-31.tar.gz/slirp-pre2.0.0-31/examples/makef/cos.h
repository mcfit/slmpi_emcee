double cos(double x);
